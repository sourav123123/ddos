# DDos-Attack
A distributed denial-of-service (DDoS) attack is one of the most powerful weapons on the internet. When you hear about a website being “brought down by hackers,” it generally means it has become a victim of a DDoS attack. In short, this means that hackers have attempted to make a website or computer unavailable by flooding or crashing the website with too much traffic.

#### Requirements :
```
Git
Python3
```

This is a simple DDoS Attack tool and even a begginer hacker can use this.
##### Run the following commands :
##### Linux : 
```
sudo apt install git, python3
git clone https://github.com/ProgrammerGaurav/DDos-Attack.git
cd DDos-Attack
chmod +x *
python3 run.py
```
This tools sends bots to the website at <b>80 bots per second</b>
So eg: If the website has the capacity to handle 400 Users per second, then you have to run this tool in 5 different terminal Window.
